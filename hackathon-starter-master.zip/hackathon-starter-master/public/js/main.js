/* eslint-env jquery, browser */
$(document).ready(() => {

  // Place JavaScript code here...

});
